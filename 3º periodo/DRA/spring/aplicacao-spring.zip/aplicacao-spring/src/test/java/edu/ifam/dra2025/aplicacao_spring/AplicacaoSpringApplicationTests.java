package edu.ifam.dra2025.aplicacao_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplicacaoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
